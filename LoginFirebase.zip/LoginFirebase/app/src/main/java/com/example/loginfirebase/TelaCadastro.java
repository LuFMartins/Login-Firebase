package com.example.loginfirebase;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.loginfirebase.databinding.ActivityTelaCadastroBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class TelaCadastro extends AppCompatActivity {

    private ActivityTelaCadastroBinding binding;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTelaCadastroBinding.inflate(getLayoutInflater());

        EdgeToEdge.enable(this);

        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mAuth = FirebaseAuth.getInstance();
    }


    public void voltartp(View view) {
        startActivity(new Intent(TelaCadastro.this, MainActivity.class));
    }

    public void validarDados(View view) {
        String email = binding.emailCd.getText().toString().trim();
        String senha = binding.senhaCd.getText().toString().trim();

        if(!(senha.isEmpty() || email.isEmpty())){
            binding.progressBar.setVisibility(view.VISIBLE);
            criarContaFirebase(email, senha);
        } else {
            Toast.makeText(TelaCadastro.this, "Email ou Senha não inseridos!", Toast.LENGTH_SHORT).show();
        }
    }

    public void criarContaFirebase(String email, String senha){
        mAuth.createUserWithEmailAndPassword(
                email,senha
        ).addOnCompleteListener(task -> {
            if(task.isSuccessful()){
                finish();
                startActivity(new Intent(TelaCadastro.this, Logado.class));
            }else{
                binding.progressBar.setVisibility(View.GONE);
                Toast.makeText(TelaCadastro.this, "Ocorreu um Erro!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}