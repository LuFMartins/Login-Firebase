package com.example.loginfirebase;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.loginfirebase.databinding.ActivityRecuperarSenhaBinding;
import com.example.loginfirebase.databinding.ActivityTelaLoginBinding;
import com.google.firebase.auth.FirebaseAuth;

public class RecuperarSenha extends AppCompatActivity {

    private ActivityRecuperarSenhaBinding binding;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRecuperarSenhaBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mAuth = FirebaseAuth.getInstance();
    }

    public void validarDados(View view){
        String email = binding.emailLg2.getText().toString().trim();

        if(!email.isEmpty()){
            binding.progressBar3.setVisibility(View.VISIBLE);
            emailRecuperacao(email);
        } else {
            Toast.makeText(this, "Email não inserido!", Toast.LENGTH_SHORT).show();
        }
    }
    public void emailRecuperacao(String email){
        mAuth.sendPasswordResetEmail(email).addOnCompleteListener(task -> {
            if(task.isSuccessful()){
                binding.progressBar3.setVisibility(View.GONE);
                Toast.makeText(this, "Email enviado! De uma olhada na Caixa de Entrada", Toast.LENGTH_SHORT).show();
            } else {
                binding.progressBar3.setVisibility(View.GONE);
                Toast.makeText(this, "Ocorreu um Erro!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void voltartp(View view) {
        startActivity(new Intent(RecuperarSenha.this, MainActivity.class));
    }
}