package com.example.loginfirebase;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.loginfirebase.databinding.ActivityTelaLoginBinding;
import com.google.firebase.auth.FirebaseAuth;

public class TelaLogin extends AppCompatActivity {

    private ActivityTelaLoginBinding binding;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTelaLoginBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mAuth = FirebaseAuth.getInstance();
    }

    public void voltartp(View view){
        startActivity(new Intent(TelaLogin.this, MainActivity.class));
    }

    public void esqueciSenha(View view) {
        startActivity(new Intent(TelaLogin.this, RecuperarSenha.class));
    }

    public void validarDados(View view) {
        String email = binding.emailLg.getText().toString().trim();
        String senha = binding.senhaLg.getText().toString().trim();

        if(!(senha.isEmpty() || email.isEmpty())){
            binding.progressBar2.setVisibility(view.VISIBLE);
            LoginFirebase(email, senha);
        } else {
            Toast.makeText(TelaLogin.this, "Email ou Senha não inseridos!", Toast.LENGTH_SHORT).show();
        }
    }

    public void LoginFirebase(String email, String senha){
        mAuth.signInWithEmailAndPassword(
                email,senha
        ).addOnCompleteListener(task -> {
            if(task.isSuccessful()){
                finish();
                startActivity(new Intent(TelaLogin.this, Logado.class));
            }else{
                binding.progressBar2.setVisibility(View.GONE);
                Toast.makeText(TelaLogin.this, "Email ou Senha incorretos!", Toast.LENGTH_SHORT).show();
            }
        });
    }


}